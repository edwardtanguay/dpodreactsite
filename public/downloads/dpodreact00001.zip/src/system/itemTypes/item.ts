class Item {

    constructor(id: number) {

    }
}

export default Item;
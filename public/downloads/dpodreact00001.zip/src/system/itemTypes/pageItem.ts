import Item from './item';

class PageItem extends Item {

    constructor(id: number) {
        super(id);
    }
}

export default PageItem;



import '../styles/pageHome.scss';

function PageHome() {

	return (
		<div className="page page_home">
			<p>Welcome to this site.</p>	
		</div>
	)
}

export default PageHome;
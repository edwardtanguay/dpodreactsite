export interface IPageItem {
	idCode: string;
	title: string;
}
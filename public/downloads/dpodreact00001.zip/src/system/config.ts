export const getBackendPort = () => {
    return 6625;
}
